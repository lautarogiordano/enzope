
from ..src.graphs import graph_class